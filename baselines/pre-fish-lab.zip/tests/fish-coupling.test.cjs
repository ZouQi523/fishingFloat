'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const T = require('../src/tackle.js');
const dt = 1 / 240;
const vec = (x = 0, y = 0, z = 0) => ({ x, y, z });
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
const digest = value => crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const legacySnapshot = rig => { const { lastInteraction, ...legacy } = rig.snapshot(); return legacy; };

// Captured BEFORE editing tackle.js, by executing its original source in a VM.
// Original source SHA256: 001e46d061a8bc7ff41f6ab77d463ce766b42c87123cc763f48ee5f7bcc2ed60
// Hashes cover EVERY original snapshot field (including curves, reactions, options,
// six-node velocities and sliding coordinate), not rounded/selected coordinates.
const baseline = [
  { options: {}, hashes: [
    '9c7a05615fa9b9857f43937cec4a2dfe9116b88c0e0a7eeb38898d4ef883c34f',
    'ca9a219a410b2ce14074a0cae137958f1eaf5784ff18bb54b85f25d0063ef26f',
    '81a8e4cd62cbdf47ed5708d435ffd7bd4c4c2b7f51adf85a9a770d73051ba6c6',
    '10b87194f83d1831743c5ab861133c905a57d737974c22b11f71132f76f39b74'
  ], finalFoot: vec(-.1892762882353487, .5947000674218229, .025076082151009375) },
  { options: { leadLocked: false, leadAboveSwivel: .08 }, hashes: [
    'cb8726c1d719fe1cf0e62835623ce1135d9ec8624b84211b9bc91415c323f699',
    '63a71a5c0e474c5ec3fd60d13e2cb3e7bd41ea8bf239c5931bc16395af705cb1',
    '86bfb7f3ffa577213d365622a505843bbd2cfed73bf58ebd3578da939afc630e',
    'dcd0f3b2ffd0e759ad755b1728c74c826653fa9f6beae316da22b74ca892cf69'
  ], finalFoot: vec(-.19424889308926035, .5952838392213549, .025067204778546206) },
  { options: { floatToSwivel: .9, leadMassG: 8, baitMassG: 1.2, leaderLengths: [.18, .22] }, hashes: [
    '626d995ff9b8c2597d42e361e30ed8bd5bb9c4bd34003949ff20814c5a98ccbb',
    'b59a9453ccaa1216db2f3aa2ddf8e28277c1721de14be4851e699f4cdb5137fb',
    'b0cbc16d7bfb80ffb9d5bad9b1f0a484574b658a38bcee6ba5362e183c0a89cd',
    'c0c3a33800a0e51d39571de7e58a700d0e4a6359e7cee738eb835dca390a89d7'
  ], finalFoot: vec(-.5609992400898658, .8205935917554621, .024628151970644985) }
];

test('uncoupled and explicit zero-force trajectories exactly match pre-change VM baselines', () => {
  for (const fixture of baseline) {
    for (const interaction of [undefined, {}, { hooks: [vec(), vec()], lineContacts: [] }]) {
      const rig = T.create(fixture.options);
      [0, .1, .4, 1.5].forEach((seconds, i) => {
        rig.step(seconds, interaction);
        assert.equal(digest(legacySnapshot(rig)), fixture.hashes[i]);
      });
      assert.deepEqual(rig.snapshot().nodes.floatFoot, fixture.finalFoot);
    }
  }
});
