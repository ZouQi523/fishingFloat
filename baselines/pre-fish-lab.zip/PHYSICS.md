# FLOAT LAB 物理模型与 API

## 当前页面的物理权威

当前 3D 页面由 [TaiwanRig](<src/tackle.js>) 推进完整台钓线组；[页面程序](<src/app.js>) 只消费同一份节点位置、姿态、线形、接触和受力快照，不再用一维平衡高度驱动画面。

[FloatPhysics](<src/physics.js>) 仍提供共享浮漂轮廓、体积表、材料密度、常量和铅卷尺寸；其旧版一维 `evaluate/equilibrium/step` 保留供兼容与独立验证，**不是当前 GUI 的线组求解器**。文末单独说明旧 API，不能把其等长短子线、无竿尖边界的结论套到当前页面。

内部长度使用 m、体积 m³、时间 s、质量 kg、力 N；名字带 `MassG` 的输入及 `lineMassG` 等输出明确使用 g。坐标 y 向上，默认水面 y=0.83 m、床面 y=0.055 m。

## 1. 连续拓扑与守恒长度

```text
固定竿尖 → 水上/入水风线 → 漂座（浮漂脚）
                           ↓ 主线继续穿过铅座孔
                        上定位豆
                        空心铅皮座 + 铅卷
                        下定位豆
                           ↓ 主线末段
                        独立八字环上眼
                        八字环下眼
                         ↙       ↘
                    短子线       长子线
                    钩 + 饵      钩 + 饵
```

- 八字环是独立物理节点与独立场景对象，不是铅座的附属渲染件。主线在上眼终止；两根子线都从下眼出发，下眼比环节点低 6 mm。
- `mainLength` 是从竿尖到八字环的主线材料总长，**包含风线**，不含双子线。`floatToSwivel` 是漂座以下主线材料长，不是端点竖直高差。
- 风线长 `Lwind = mainLength - floatToSwivel`；漂座至铅座长 `Lupper = floatToSwivel - leadCoordinate`；铅座至环长 `Llower = leadCoordinate`。三段之和始终为 `mainLength`。
- 移漂座只是重新分配风线与水下主线；移定位豆只是重新分配上、下铅段。都不会凭空增加线长。**当前页面是一副已绑好的线组：主线固定 120 cm，子线固定 12 / 15 cm，不提供裁线或改线长操作。** 页面调试入口也保护这三个长度；底层 TaiwanRig 模块仍支持其他长度，供独立物理测试使用。
- 两根子线独立定长，默认 12 / 15 cm，不再是旧模型的两根等长 5.8 cm 线。

### 锁铅与限定行程跑铅

`leadAboveSwivel` 是下止点对应的铅座距环材料坐标。锁铅时 `leadCoordinate = leadAboveSwivel`，上、下段分别受固定长度的只拉约束。

跑铅时：

```text
leadAboveSwivel <= leadCoordinate <= leadAboveSwivel + leadTravel
Lupper + Llower = floatToSwivel
```

主线经理想无摩擦通孔滑移；求解器使用合长/滑轮式只拉约束，并限制上、下段最大跨度。材料坐标在余量允许时受重力与经验黏性阻尼更新，不能理解成完整的孔内接触或摩擦动力学。两颗铅豆是主线材料坐标上的止点标记，不是主线终点；四颗漂豆分布在漂座两侧。页面从跑铅切回锁铅时，以当前铅座坐标更新下止点，避免无意锁回旧位置。

## 2. 实际默认参数与配件

[TaiwanRig 源码](<src/tackle.js>) 的 `defaults`：

| 参数 | 默认值 | 含义 |
|---|---:|---|
| `leadMassG` | 4 g | 只计铅皮，不含配件 |
| `floatMassG` | 0.600 g | 浮漂干质量 |
| `baitMassG` | 0.340 g | 双饵总质量，各一半 |
| `waterY / bottomY` | 0.830 / 0.055 m | 水面 / 水平床面 |
| `waterDensity` | 998.23 kg/m³ | 默认淡水密度 |
| `lineMaterial` | `nylon` | 尼龙 |
| `mainDiameter / subDiameter` | 0.22 / 0.16 mm | 主线 / 子线实体等效直径 |
| `mainLength` | 1.20 m | 含风线的主线总长，页面中固定 |
| `windOnSurface` | `true` | 松风线的理想界面保持 |
| `floatToSwivel` | 0.42 m | 漂座至八字环材料长 |
| `leadAboveSwivel` | 0.055 m | 铅座下止点坐标 |
| `leadTravel` | 0.08 m | 跑铅向上行程，锁铅时不启用 |
| `leadLocked` | `true` | 默认夹紧两豆 |
| `leaderLengths` | `[0.12, 0.15]` m | 长短双子线 |
| `rodTip` | `{x:-0.50,y:1.10,z:0.025}` m | 固定竿尖边界 |

默认风线为 78 cm，锁铅上段为 36.5 cm，下段为 5.5 cm。默认状态可能包含钩触底或竿尖承重，不能预设为“4 g 必定自由半水、露固定目数”。页面启动调用 `settle(20)`，只是先推进 20 秒，并不是静力解的承诺。

额外共享常量与配件（均计入整体重量与排水，不重复计数）：

| 部件 / 材料 | 数值 / 模型 |
|---|---|
| 浮漂 | 长 260 mm；每目轴长 15.7 mm；共享轮廓总体积约 4.489391 mL |
| 铅皮座 | **20 mm 空心轴，45 mg**；两端挡肩；模型中铅卷围绕座中心 |
| 八字环 | **35 mg**，独立节点 |
| 漂座 | **20 mg**，位于漂脚 |
| 太空豆 | **6 颗，共 12 mg**；四颗漂豆、两颗铅豆 |
| 鱼钩 | 每钩 25 mg，钢密度 7850 kg/m³ |
| 饵 | 默认密度 1100 kg/m³；球体，各约 3.329 mm 半径 |
| 尼龙 / 碳线 / PE | 1140 / 1780 / 970 kg/m³ |
| 铅 | 11340 kg/m³；有铅时卷高 18 mm、内半径 1.1 mm，外半径由真实铅体积决定 |
| 塑料等效密度 | 1250 kg/m³，用于座与豆的集总排水 |
| 重力加速度 | 9.80665 m/s² |

双饵每球半径 `r = cbrt((baitMassG / 2000 / baitDensity) * 3 / (4π))`。`baitMassG=0` 时无饵，鱼钩仍存在。改质量不改变浮漂外形体积；改铅质量会改变铅卷外半径。

## 3. 动力学与只拉约束

### 六节点 PBD

六个运动节点依次为：漂脚、漂尖、铅座、八字环、短子线钩、长子线钩。竿尖是固定边界，不是第七个运动节点。

每次 `step(dt)` 分成 `ceil(dt*240)` 个子步，因此子步不超过 **1/240 s**；每步进行 **24 次约束迭代**。求解顺序包含：

1. 对集总质量施加真实重力、排水浮力和经验速度阻尼，预测位置。
2. 漂脚—漂尖保持 260 mm 的双向刚体长度约束；其余线段只在端点距离大于材料长度时纠正，**线能拉、不能推**。
3. 锁铅使用两段固定材料长；跑铅使用总长滑轮式约束与止点边界；两根子线分别约束。
4. 双饵球做简单互不重叠投影；六节点及浮漂宽部对水平床面做非穿透投影。
5. 由修正后位移回算速度；床面接触附加非弹性切向速度衰减。此为稳定化阻尼，不是标定的库仑摩擦模型。

浮漂质量按轴向质心距漂脚 7.5 cm 分配到两端，浮力按浸水分布分配，因而浮漂可以倾斜、侧躺，不再强制竖直。有效惯性额外加入约 `0.4*rhoWater*V_floatWet` 的附加水质量。阻尼和附加质量都是工程近似，不是 CFD。

有限迭代会有小的长度误差；`evaluation.maxLengthError` 给出浮漂刚长误差及线段正伸长量的最大值。修改长度后 `configure` 不立即投影，下一次积分才消解暂时的约束不一致。

### 线自重、浮力与松弛线形

```text
A = π*d²/4
Vline = A*L
mline = rhoLine*Vline
Bline = rhoWater*g*VlineWet
Wline = mline*g
```

计入风线、水下两段主线、两根子线的全部材料质量。线载荷与惯性各半集总到两个端点；风线竿端那一半计入总重及竿端反力，但不加入运动节点惯性。

水下线绘制为 24 段准静态弧线，搜索弓高使折线弧长近似等于材料长度。重于水的松线下垂，完全浸水且轻于水的松 PE 上拱；床面/水面限制处多余长度横向铺开，不删线。浸水折线比例决定线排水。**这些弧线没有独立运动节点，不是完整柔性线动力学，也不是精确悬链线解。** 渲染进一步采样造成的弧长误差也不代表材料可拉伸。

#### 松风线的理想水面承托

`windOnSurface:true` 是默认的**未被主动压入、尚能被界面托住的风线**教学假设，不把“尼龙密度大于水”直接等同于“松风线必须沉到床面”。有足够材料长度时，风线由空气段、水面铺展段、漂座入水段组成；两个接水位置采用切向连续的弯曲过渡，不再用互相垂直的直腿拼接。弯曲消耗的材料长度也参与求解，多余长度在水面横向展开；漂座仍在水下时，末段仍正常入水，不把整条风线强行贴在水面。物理曲线按切线转角自适应细分，长松线的中部转弯也会加密；最后求材料长度时固定细分网格，避免细分数量变化引入弧长跳变。曲线的实际浸水比例和实际贴水段参与排水与承托力计算，圆滑不是渲染层另画的一条装饰线。风线圆管与辅助线共用 256 点采样，其余各段保留 64 点；开启辅助线时，它也进入水面的透射与反射图，避免刚入水的圆弧在画面上缺一截。

- 端点距离已逼近材料长度，或现有材料不足以经水面连接两端时，自动退回普通张力线；提竿可以拉紧、拉离水面，不是永久锁 y 坐标。
- 水面段名义上按半截面浸水计排水；极高水密度/极轻线材时降低该比例，不制造向下的界面力。
- `surfaceSupportN` 只补足这段线自身尚未被排水浮力抵消的重力，不额外支撑铅或钩；按与线载荷相同的集总方式作用，并进入竿反力和整体外力闭合。
- `windSurfaceLength` 是被界面承托的材料长度，质量仍只由固定材料体积计算。`windOnSurface:false` 可在底层模块中关闭该假设，用于比较，不在简单操作界面增加开关。

这是准静态理想界面保持模型；平滑过渡是受材料长度约束的几何近似，不是根据线材弯曲刚度、弯矩及真实张力求得的精确弯曲半径。**没有求解接触角、润湿滞后、实际表面张力容量、吸水后下沉或水面波动**；不能据此宣称所有线材、所有时间和水质下都必定漂浮。

### 浮漂浸水积分

浮漂轮廓由共享 `radius(s)` 定义，`s` 从漂尖向漂脚量起：

```text
0 <= s < .125:    r = .00055 + .00030*s/.125
.125 <= s < .20:  r = .00085 + .00475*sin(π*(s-.125)/.075)^.9
.20 <= s <= .26:  r = .00085 - .00020*(s-.20)/.06
```

`FloatPhysics.volumeBelow(s)` 是从 s 至漂脚的体积，由 4096 个中点积分格及插值得到。`TaiwanRig.floatSubmersion(foot,top,waterY)` 复用这张表：

- 正立与倒立的轴向裁切精确保留共享体积表的结果；这里“精确”是相对于该离散体积表，不是解析积分。
- 倾斜时分 48 个轴段；一般姿态用 12 点径向求积卷积轴向浸水量，近水平时每段再分 4 段并使用圆截面浸水面积公式。
- 返回 `{volume,footShare,topShare,center}`；体积在 `[0,totalVolume]` 内，浮力分配给漂脚、漂尖以形成姿态响应。
- 浮心位置是轴段轴向分配近似，并非浸水三维截面的完整精确质心；不独立求解绕浮漂长轴的转动。

饵球排水采用球冠体积 `Vcap=π*h²*(r-h/3)`，`h` 限制在 `[0,2r]`。铅卷、钩、座、豆、八字环穿水面的排水是集总包络近似。

## 4. 外力、竿尖承重与状态读数

静止且数值误差足够小时，整体应满足向量平衡：

```text
B + W + Rrod + Nbed + Ssurface ≈ 0
竖直分量：buoyancyN - weightN + rodReaction.y + bottomSupportN + surfaceSupportN ≈ 0
```

动态时还存在水阻和惯性；不能要求上式瞬时为零。竿反力可能有横向分量，床面的切向稳定化阻尼也不在面板的竖直合力内。

**有固定竿尖时，过重线组可以由绷紧风线支持，不必沉到床面。** 只有在竿端不能提供相应支持、无床面接触等边界条件下，完全浸没且重力大于浮力才意味着持续向下加速。不存在人为 `SOFT_K` 水下目标弹簧，也不通过指定露目数反推位置。

快照中的 `evaluation`：

- `buoyancyN / weightN`：整套线组总浮力 / 总重力，含所有线和配件。
- `bottomSupportN`：上一子步床面位置投影推算的非负法向支持力。
- `surfaceSupportN / windSurfaceLength`：风线界面的独立向上承托力（N）/ 被承托材料长度（m）；不是额外排水体积，也不是线的额外质量。
- `rodReaction:{x,y,z}`：竿端约束与竿端分配线载荷组成的外力估计。
- `rodTensionN`、`tension.wind`：该竿端反力的模；不是只取风线约束乘子，也不是“额外浮力”。`tension.upper/lower/leaders` 是上、下铅段及双子线的约束张力估计。
- `lineMassG / lineBuoyancyG / lineApparentMassG`：全线干质量 / 排水等效质量 / 差值，单位 g，不是 N。
- `floatDisplacedVolume / displacedVolume`：浮漂 / 整套排水体积，m³。
- `exposureM`：`max(0,floatTop.y-waterY)`，仅为尖端竖直露高；倾斜时不等于沿轴露长。
- `tiltRad`：漂轴相对向上竖直的夹角。
- `staticResidualN`：`hypot(rodReaction.x, B-W+N+Ssurface+Rrod.y, rodReaction.z)`；不含水阻或接触切向阻尼，**不是收敛标志，也不保证所有静止配置都近零**。
- `contacts:{hooks:[bool,bool],lead:bool,float:bool}`：近床接触判定；`status` 按 `sunk → lead-bottom → hooks-bottom → submerged → floating` 优先级描述几何状态。`floating` 不保证无竿力或已平衡；`submerged` 不等于在水下自由平衡。

页面在漂倾角小于 20° 且露出部分仍在漂尾时才显示轴向“目数”；每目 15.7 mm。斜躺时显示倾角，漂身出水或漂尖没入时显示距离，不把任何高度都冒充调目。

## 5. TaiwanRig API

```js
// Node；浏览器使用 window.TaiwanRig（先加载 FloatPhysics）
const T = require('./src/tackle.js');
const rig = T.create({ leadMassG: 4 });

T.defaults;                        // 冻结的显式默认项
T.normalize({ mainLength: 1.2 });   // 规范化参数，含派生密度、饵半径等
T.floatSubmersion(foot, top, .83);  // 纯浸水几何查询
rig.options;                       // 参数副本
rig.velocities;                    // 六节点速度副本
rig.configure({ floatToSwivel: .50 });
rig.configure({ rodTip: { y: 1.38 } });
rig.step(1 / 60);                   // 返回 rig，供链式调用
const state = rig.snapshot();       // 不推进时间
const later = rig.settle(20);       // 推进 20 秒并返回快照
rig.reset({ cast: true });          // 重置时间、位置、速度及滑移坐标；返回 rig
```

`configure(patch)` **保留节点位置、速度和模拟时间**，只合并/规范化参数并把铅坐标钳入新边界；`rodTip` 支持分量合并。不会寻找平衡、重抛或自动清零速度。`reset()` 默认与 `{cast:true}` 一致：从统一偏高落水初态开始；`{cast:false}` 使用低 12 cm 的初态，二者都不是平衡解。

`step(dt)` 接受有限 `[0,60]` 秒，0 秒不推进；`settle(seconds=20)` 接受有限 `[0,600]` 秒，以不超过 1 秒的外层块调用同一个积分器，**只是实际时间推进，不是 equilibrium 的别名，不承诺 20 秒完全收敛**。

`snapshot()` 主要结构：

```js
{
  options, time,
  nodes: {rod,floatFoot,floatTop,lead,swivel,leaderAnchor,hooks:[p,p]},
  curves: {wind:[p],upper:[p],lower:[p],leaders:[[p],[p]]},
  markers: {floatStops:[p,p,p,p],leadStops:[p,p]},
  leadCoordinate, velocityY, velocities:[v,v,v,v,v,v], evaluation
}
// p/v = {x,y,z}；velocityY 是漂脚速度，不是漂尖速度
```

规范化会钳制非物理输入：主线 0.08–20 m，漂座深度 0.03 至 `mainLength-.02` m，下止点 0.005 至 `floatToSwivel-.005` m，跑铅行程 0 至 `floatToSwivel-leadAboveSwivel-.005` m，子线各 0.01–5 m，直径 10 μm–3 mm，浮漂质量至少 0.01 g，铅/饵质量非负，密度至少 1 kg/m³。`bottomY>=waterY` 与未知线材抛 `RangeError`。`baitDensity` 可覆盖饵密度；`lineDensity` 则由 `lineMaterial` 派生，TaiwanRig 不接受独立覆盖（与旧 FloatPhysics 不同）。这是模块输入域，**不等于 GUI 控件范围**。

## 6. 页面控制与集成

[页面程序](<src/app.js>) 创建 `TaiwanRig` 后预推进 20 秒；动画每帧将真实间隔上限设为 0.05 秒，暂停时传入 0，因此后台恢复不补算全部离线时长。所有配件、真实半径线管、标记豆与 HUD 都来自同一快照；加粗辅助线可独立关闭，不改变物理直径。

[界面模板](<src/shell.html>) 提供：

- **鱼缸只用于观察**：删除漂、漂座、铅座、竿尖等跟随标签、数值提示和操作手柄；不注册配件拾取或移动事件。点击或拖动浮漂、铅座不会改动线组，也不会打开剪铅面板。仍可旋转、缩放观察视角。
- **湖水配色与日光**：对照参考视频，原场景水面和侧面水体统一使用低饱和的黄绿/橄榄绿，透射光优先衰减蓝色，清澈时仍保留湖水色调。原有环境贴图、天空/地面半球光、暖白主光、补光、轮廓光和灯槽同步去除青蓝偏色；不另建观漂小窗背景或给小窗增加灯光。水体散射项和水面高光通过 uniform 跟踪**原场景主光的世界方向、颜色和强度，以及原半球光的天空色和强度**，不再写死一个独立高光方向。共享调色板和水体介质位于 [水体光学模块](<src/optics.js>)，日光、环境及原水体盒在 [页面程序](<src/app.js>) 设置，完全不修改物理参数。
- **水体清澈度与深度散射**：展开「更多 · 环境与受力 → 水体、线材与饵重」调节 0–100%，默认 **35% 湖水**，不再默认清澈见底；100% 是便于检查线组的清水演示，0% 完全不透视水下。每台相机的原场景折射采样带独立 `DepthTexture`，用逆投影/视图矩阵反投影近裁剪面与真实可见物体深度，再通过真实水体包围盒裁剪得到**水内光程（米）**。采用 Beer–Lambert 形式 `exp(-sigma × density × L)`，RGB 消光系数 `[6,5,8] /m`，相对密度 `(1-c)/max(c,.02)`，并按每米透射底色轻微选择性吸收；`c` 为清澈度。散射补光由共享原场景日光及半球光提供。因此浅层漂身仍隐约可见，深处漂身、线组和水底的对比度随光程衰减至不可辨认，不是整片水面等比例盖色。**原水体盒侧面使用同一介质、同一深度采样和同一参数**，不再使用固定的低透明度竖向色层；体积盒禁绘顶/底盖，避免光学合成顶盖覆盖原波纹水面的 Fresnel 反射；采样时隐藏水面及水体盒仅为避免光学自采样，最终绘制均恢复，未隐藏/裁掉任何水下钓组。两相机始终观察同一个原场景；每台相机独立绑定深度纹理与逆视图投影矩阵，小窗绘制后恢复主相机绑定。水面保留真实反射、Fresnel、波纹及出水漂尾，正交相机使用平行视线而非伪透视方向。此为**屏幕空间光程消光与简化单次散射近似**，水面按 Snell 折射余弦修正光程，并非完整折射光线追踪、多次散射或实测泥沙浓度模型。不修改水温、密度、浮力、线组配置或模拟时间。
- **左侧观漂相机**：同一个 Three.js `scene` 中的第二台相机，固定从水面上方 **20°** 观察实际浮漂；不是复制漂体、另建场景或绘制参考视频风格的假图片。主窗口与小窗调用 `renderer.render(scene, camera)` 时传入的是**同一个场景对象**，仅相机和视口不同；原始浮漂、水面、灯光、材质、鱼线、遮挡关系和渲染回调全部保留，不增补绿水背景、虚拟漂体、镜像漂模型或单独灯光。也不强行裁掉水下物体：实际水面能反射或透射到的内容由现有水体光学决定；完全没入只表示无出水漂尾，不保证透明水下没有可见物体。通过原漂体的真实世界顶点计算取景与读数，正常视野高 24 cm，水面锚点位于画面高度 56%；仅大幅出水或横躺时扩大取景，不垂直追踪漂尖抵消真实升降。小窗只读，不编造鱼口动作，也不显示水位虚线。水面仍是**原场景中的同一张网格、同一个材质**，但用每台相机自己的反射/折射目标与镜像相机重新采样整个原场景；每台相机独立执行首帧/每三帧反射更新，绘制小窗后恢复主相机水面贴图绑定及完整渲染状态。诊断信息公开场景和原始浮漂 UUID，浏览器回归验证两视图确实共享对象身份。
- **移漂 / 移铅**：分别打开与剪铅相同理念的独立全屏工作台，不改变鱼缸视角，也不在 HUD 展开滑块。[工作台模块](<src/seat-workshop.js>) 用二维放大配件、主线、刻度和原位虚线表示位置；可用鼠标或触摸直接握住漂座 / 铅皮座上下拖动，也可拖动右侧手柄。所有移动先记为草稿，点“完成 · 抛入水中”才提交对应位置并重抛；取消或 Escape 保持原线组、时间和节点，恢复默认位置也只改草稿。工作台打开期间冻结鱼缸、禁用背景操作，关闭后恢复原暂停状态；键盘焦点限制在对话框内并返回入口。方向键以 0.5 cm 微调，Shift 以 5 cm 调整，Home / End 到边界；手势取消、失去指针捕获或尺寸变化撤销该次拖动。
- 常规漂座距环 **18–80 cm**，下限必要时抬高以保留铅座位置及原跑铅行程；铅座下止点至少 **2 cm**，上限同时保留漂座下方 **2.5 cm** 间隙及原跑铅行程。部件宽度为放大示意，纵向刻度按位置缩放；这不是把手伸入鱼缸，工作台也不提供任意点刻度跳位。
- 主线 **120 cm**、短子线 **12 cm**、长子线 **15 cm** 固定。`floatLab.configure` 也不会改掉这些长度；底层 `TaiwanRig` 的可配置参数域不受这层页面约束影响。
- 环境、线材、受力等收在默认关闭的“更多”面板中。进阶锁铅开关保留；释放时由两止点限定行程，重新夹紧捕获当前材料坐标。
- **“提竿 55 cm”** 切换竿尖 y 边界相对基准高度增加 0.55 m，再点放回；x/z 不变。它移动真实边界并经张力牵引，不是直接给漂/铅/钩添加展示位移。画出的竿身只是几何参照，不是弹性竿模型。
- 水温 0–40°C 换算淡水密度；三种线材；主线直径 0.05–1 mm、子线 0.04–1 mm；双饵总重 0–5 g；精确铅重 0–10 g、0.01 g 步长。
- HUD 常驻 **移漂 / 移铅 / 剪铅皮** 三个常用入口；剪铅只从面板按钮进入，保留原剪铅画布、确认、取消和恢复整块操作。另有全缸（初始）/线组/水线特写、暂停、重置落水、线形辅助及默认关闭的整体受力标记。
- “重置落水”只重置当前参数的动力初态；“恢复线组”恢复默认参数、取消提竿、重抛并切回全缸。剪铅面板的整块恢复值 5 g 不等于默认线组的 4 g。

调试入口 `window.floatLab` 暴露 `physics`（旧 FloatPhysics）、`tackle`（TaiwanRig）、`getState()`、`getRenderState()`、`configure(patch)`、`settle(seconds)`、`setLead`、`setView`、`recast`。当前测试应检查 `evaluation.contacts`、`rodReaction` 等字段，不要依赖旧版 `netForceN` 或 `equilibrium()`。

## 7. 已知边界：教学近似，不是完全真实

1. 只有六个运动节点和固定竿尖；没有弹性竿弯曲、线材伸长、扭转、完整柔性线波动或抛投空气动力学。
2. 跑铅孔为理想无摩擦，松线形状为准静态弧线；未求解穿线、缠绕、打结、挂底、线—配件自碰撞或实际摩擦。床面切向衰减只是数值稳定化。
3. 接触对象是水平床面与简化包络，不是玻璃缸壁/水草/砂砾逐三角形碰撞；可以超出画出的缸壁。饵球仅做一对互不重叠，钩形几何碰撞未求解。
4. 无风、走水、鱼口、水面流场或完整流体自由面；装饰波纹、水草运动、折射和焦散不向线组添加虚构外力。
5. 浮漂倾斜排水和浮心、附加水质量、阻尼、配件部分浸水均有近似；风线只有理想界面保持，不求解真实表面张力场、毛细接触角/滞后、润湿历史或气泡。不能宣称亚 0.01 g 实物绝对精度。
6. 饵不吸水、不雾化溶解；线密度为实体等效值，不拟合编织空隙和浸水时间效应。六颗豆的质量分摊到漂脚/铅座，而非逐豆独立动力学。
7. PBD 的约束反力来自离散位置修正，有限步长、迭代顺序与参数突变会影响瞬时读数。判断静止须同时看速度、接触、张力与残差，不能只看露目或竖直合力近零。

## 8. 保留的 FloatPhysics 一维兼容接口

以下只适用于 [旧版模块](<src/physics.js>) 自身：固定竖直浮漂、10.5 cm 主线、两根相同 5.8 cm 子线、无竿尖风线。配件几何以 `leadTopY` 为基准；当前 TaiwanRig 的铅节点则在铅座中心，不能混用两套 offset。

```js
const P = require('./src/physics.js');
P.constants; P.materials;
P.radius(s); P.volumeBelow(s); P.totalVolume;
P.leadDimensions(5);
P.rigLayout(topY, 5, options);
P.evaluate(topY, 5, options);
P.equilibrium(5, options);
P.step({ topY, velocityY }, dtSeconds, 5, options);
```

- `leadDimensions` 返回 `{height,radius,innerRadius,volumeM3,massKg,centerOffsetY,bottomOffsetY,subAnchorOffsetY}`；offset 从旧版铅顶向下为负。
- `rigLayout` 返回漂/铅/钩/饵高度、`mainSlack/subSlack`、`minimumTopY`、`contactTopYs`、`contacts` 和铅尺寸；旧版两钩同高度。松弛量是线长减端点竖直距离，不是弹性伸长。
- `evaluate` 返回扁平受力结果：`topY,buoyancyN,weightN,netForceN,massKg,displacedVolume,floatDisplacedVolume,leadDisplacedVolume,lineMassG,lineBuoyancyG,lineApparentMassG,bottomSupportN,bottomSupportG,suspendedMassKg,effectiveMassKg,contact,contacts,status,layout,strands,options`。`contact` 是 `contacts` 的旧兼容别名。
- strand 中的 `topLoadN/bottomLoadN/floorLoadN` 是线自身有效重量的分配，不是独立线张力；PE 上拱使用 `shape:'arch',highY,surfaceLength`，不能拿 `lowY` 当上拱弯折点。
- `equilibrium` 检查接触边界并在连续区间二分；返回扁平 `evaluate` 结果加 `converged`，读取 `result.topY`，不是 `result.evaluation.topY`。旧版无竿端支持时，完全浸没过重线组不能靠任意水下目标弹簧悬停；这不意味着当前有竿模型的重铅必沉底。
- 旧 `step` 返回 `{topY,y,velocityY,velocity,evaluation}`，不就地修改输入；dt 为有限 0–10 秒。半隐式积分最大子步 1/240 秒，含线性/二次阻力、约 0.35 倍排水质量的附加水质量、接触及拾起床上质量时的非弹性处理。它不是六节点 TaiwanRig 积分器。
- 旧 options 支持水面/床面/水密度、漂质量、线材/密度/直径、饵密度/质量、`linearDrag`、`dragCoefficient`。旧模块水密度默认 998.2；省略 `baitMassG` 时使用两球半径 4.2 mm 的历史兼容值，**不是 TaiwanRig 默认 0.34 g**。

## 9. 测试、构建与图形验证

纯 Node 单元测试不需要 DOM、Three.js 或 Chrome：

```sh
node --test tests/*.test.cjs
```

[旧模型测试](<tests/physics.test.cjs>) 覆盖共享体积、真实线重、浮力、接触和旧一维动力学；[台钓线组测试](<tests/tackle.test.cjs>) 覆盖 UMD/CommonJS、正立/倒立/水平浮漂排水、默认质量、独立八字环、守恒长度、配置保留状态、跑铅范围、竿端承重、只拉约束、床面净空及实际时间推进；另覆盖松风线的空气腿/水面段/入水腿、泛化长度与移座质量守恒、三种线材的界面承托闭合、贴近绷紧时的接触消失，以及提竿/放竿的脱离和恢复。平滑风线检查整条三维曲线的转角，而不只检查两个接口；[界面端点测试](<tests/wind-interface.test.cjs>) 额外覆盖竿端/漂座恰在水面时的实际贴水长度、承托力及两端重合时的闭合水面线圈。测试容差和断言才是数值保证，不应把历史通过数量或旧版露目值作为当前验收结论。

离线单文件构建：

```sh
python3 build.py
```

[构建脚本](<build.py>) 将本地 Three.js、OrbitControls 与 **physics → tackle → optics → seat-workshop → float-scope → app** 顺序内嵌进 [界面模板](<src/shell.html>)，生成 [单文件入口](<index.html>)；可直接以 `file://` 打开，不依赖 CDN。仅修改源码不会自动更新生成入口。[原 2D 页面](<index-2d.html>) 保留，不参与此构建，也不由台钓模型改写。

图形层 [光学模块](<src/optics.js>) 的折射、反射、焦散和水面效果属于视觉近似，不改变排水与接触求解。可在获准使用浏览器时检查桌面/移动端视口、默认全缸、面板移漂/移铅、无配件拾取的视角观察、锁铅/跑铅、提竿、触底、暂停、真实线径与辅助线开关的一致性。

[浏览器检查脚本](<browser-check.cjs>) 连接已有 Chrome 调试端口 9334，需要提供全局 `WebSocket` 的 Node（例如 Node 24）。它会导航页面、调整视口并写截图/JSON，**不是纯只读 Node 测试**：

```sh
node browser-check.cjs
MOBILE=1 node browser-check.cjs
```

`--regression` 运行当前 TaiwanRig 的[浏览器交互断言](<tests/browser-actions.cjs>)，覆盖独立移漂 / 移铅工作台、草稿提交 / 取消及边界、无场景标签及禁用配件拾取、固定线长、连续拓扑、线重、水面承托与受力显示、锁铅 / 跑铅、提竿牵引、剪铅、暂停、外部配置和视口布局。`--drag` 运行[真实 CDP 鼠标、触摸与键盘检查](<tests/browser-drag.cjs>)，验证工作台配件和手柄拖动、键盘调整、草稿隔离、确认 / 取消、指针捕获丢失和触摸取消回滚、焦点限制与返回、原运行 / 暂停状态恢复；同时保留鱼缸点击 / 拖动不改线组、不误开剪铅以及旋转 / 缩放视角检查。桌面和手机视口分别执行。

```sh
node browser-check.cjs --regression preview-updated.png
MOBILE=1 node browser-check.cjs --regression preview-mobile-regression.png
node browser-check.cjs --drag preview-tank.png
MOBILE=1 node browser-check.cjs --drag preview-mobile.png
node browser-check.cjs --scope preview-scope-camera.png
MOBILE=1 node browser-check.cjs --scope preview-scope-camera-mobile.png
node browser-check.cjs --water preview-water-opaque.png
MOBILE=1 node browser-check.cjs --water preview-water-opaque-mobile.png
```

本次验证：82 项 Node 单元测试全部通过（含 19 项同场景观漂相机测试、18 项多相机水体光学/深度消光/真实光源绑定/资源释放测试）；1440×1000 桌面和 390×844 手机视口各通过 89 项通用回归、147 项真实指针/工作台交互检查、147 项观漂相机断言及 58 项水体清澈度/深度散射断言，JavaScript 错误为 0。光学测试覆盖独立深度附件、正确的每相机逆视图投影矩阵、正交平行视线、共享水体边界/消光参数、实时原光源及渲染资源释放。清澈度验证读取两视图真实 GPU 像素：0%、35%、100% 画面不同，恢复 100% 后画面完全一致；相机实际静止后才比较固定像素，并检查滑条键盘操作及物理状态不变。新增脱离 DOM 的独立 GPU 标靶夹具直接调用同一生产水面/侧面材质，覆盖透视/正交 × 水面/侧面 × 深度 1.5 cm/80 cm × 清澈度 100%/35%/0% 共 24 组黑白对比度采样、23 项断言：35% 保留浅层目标至少 45% 的清水对比度，80 cm 深层目标降至清水对比度的 4% 以下，0% 即使浅层也不可分辨；夹具不修改用户场景或物理，完成后释放 WebGL 资源。相机检查验证原始场景/浮漂 UUID 相同、20° 独立视角、真实位姿和渲染状态恢复；不再将复制模型视为同场景相机。浏览器检查显式激活页面的可见/焦点状态并等待实际动画帧，恢复模拟时验证物理时间推进。移动端检查采用桌面 Chrome 的移动视口，不等同于真机触控或 Safari 验证。

漂座内毫米级线孔走线按共点接头近似，渲染线孔中心与求解承力点一致；不模拟座内线体与漂脚的局部接触。全缸观察在手机上合并末端标签以避免重叠，细节请切到水线或线组特写。
