#!/usr/bin/env python3
"""把 three.js（ESM）+ OrbitControls + app.js 打成一个「双击即可打开」的单文件 HTML。

three.module.js 结尾只有一条 export { ... }，把它改写成 window.THREE = { ... } 就变成经典脚本；
OrbitControls 的 import/export 同样改写。这样不需要本地服务器，file:// 直接可跑。
"""
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parent
VENDOR = ROOT / "vendor"
SRC = ROOT / "src"


def three_to_classic(src: str) -> str:
    idx = src.rindex("export {")
    body = src[:idx]
    tail = src[idx + len("export {"):].strip()
    assert tail.endswith("};"), tail[-20:]
    names = tail[:-2].strip()
    entries = []
    for part in names.split(","):
        part = part.strip()
        if not part:
            continue
        if " as " in part:
            a, b = [x.strip() for x in part.split(" as ")]
            entries.append(f"{b}: {a}")
        else:
            entries.append(f"{part}: {part}")
    # 包进 IIFE：class/const 在经典脚本里属于共享的全局词法作用域，
    # 不隔离的话会和 OrbitControls 里的同名解构冲突
    return "(function(){\n" + body + "\nwindow.THREE = {" + ",".join(entries) + "};\n})();\n"


def orbit_to_classic(src: str) -> str:
    m = re.search(r"import\s*\{(.*?)\}\s*from\s*['\"]three['\"];", src, re.S)
    if not m:
        raise SystemExit("OrbitControls: import 语句未找到")
    src = src[: m.start()] + "const {" + m.group(1) + "} = window.THREE;" + src[m.end():]
    src = src.replace("export { OrbitControls };", "window.OrbitControls = OrbitControls;")
    return "(function(){\n" + src + "\n})();\n"


def guard(js: str) -> str:
    # 防止脚本里出现 </script> 提前闭合
    return js.replace("</script", "<\\/script")


def main():
    three = guard(three_to_classic((VENDOR / "three.module.js").read_text(encoding="utf-8")))
    orbit = guard(orbit_to_classic((VENDOR / "OrbitControls.js").read_text(encoding="utf-8")))
    app = "\n".join(guard((SRC / name).read_text(encoding="utf-8"))
                    for name in ("physics.js", "tackle.js", "fish-behavior.js", "fish-lab.js", "crucian-mesh.js", "fish-view.js", "fish-panel.js", "optics.js", "seat-workshop.js", "float-scope.js", "app.js"))
    shell = (SRC / "shell.html").read_text(encoding="utf-8")

    html = (shell
            .replace("/*__THREE__*/", three)
            .replace("/*__ORBIT__*/", orbit)
            .replace("/*__APP__*/", app))
    out = ROOT / "index.html"
    out.write_text(html, encoding="utf-8")
    print(f"built {out}  ({len(html)/1024/1024:.2f} MB)")


if __name__ == "__main__":
    main()
