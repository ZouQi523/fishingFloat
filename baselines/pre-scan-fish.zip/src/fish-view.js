/* Pure original-scene fish rendering. No physics, force, hooks or hidden scene. */
(function () {
  'use strict';
  window.FishView = {
    create({ THREE: T, scene }) {
      const asset = window.CrucianMesh;
      if (!asset || !asset.meshes) throw new Error('Load crucian-mesh.js before FishView.create');
      const root = new T.Group(); root.name = 'CrucianFish'; root.visible = false;
      scene.add(root);
      const tail = new T.Group(); tail.name = 'CaudalPivot'; tail.position.x = -.061;
      root.add(tail);
      // Derive the mouth from the actual exported lip vertices, not a free marker.
      const lipData = asset.meshes.find(m => m.name === asset.mouthSource.mesh);
      if (!lipData) throw new Error('Crucian mesh has no real oral rim');
      const maxLipX = Math.max(...lipData.positions.filter((_, i) => i % 3 === 0));
      const rimPoints = new Map();
      for (let i = 0; i < lipData.positions.length; i += 3) {
        if (Math.abs(lipData.positions[i] - maxLipX) > 1e-8) continue;
        const p = lipData.positions.slice(i, i + 3);
        rimPoints.set(p.join(','), p);
      }
      const mouth = new T.Vector3();
      rimPoints.forEach(p => mouth.add(new T.Vector3().fromArray(p)));
      mouth.divideScalar(rimPoints.size);
      const mouthSource = { mesh: lipData.name, kind: 'actual exported front lip vertices centroid', vertexCount: rimPoints.size };
      const direction = new T.Vector3(1, 0, 0), axis = new T.Vector3(1, 0, 0);
      const physicalMouth = new T.Vector3(), actualMouth = new T.Vector3();
      const geometries = [], materials = [];
      let skinTexture = null;
      if (asset.skinTexture) {
        const s = asset.skinTexture, bytes = atob(s.data), rgba = new Uint8Array(s.width*s.height*4);
        for (let i=0; i<bytes.length; i++) {
          const v=bytes.charCodeAt(i);rgba[i*4]=v;rgba[i*4+1]=v;rgba[i*4+2]=v;rgba[i*4+3]=255;
        }
        // Embedded raw pixels are synchronous and work on file:// with no image loader.
        skinTexture = new T.DataTexture(rgba,s.width,s.height,T.RGBAFormat);
        skinTexture.colorSpace = T.NoColorSpace;
        skinTexture.magFilter = T.LinearFilter;skinTexture.minFilter = T.LinearMipmapLinearFilter;
        skinTexture.generateMipmaps = true;skinTexture.needsUpdate = true;
      }
      let enabled = false, disposed = false, time = 0, state = 'disabled';
      asset.meshes.forEach(data => {
        const geometry = new T.BufferGeometry();
        geometry.setAttribute('position', new T.Float32BufferAttribute(data.positions, 3));
        geometry.setAttribute('normal', new T.Float32BufferAttribute(data.normals, 3));
        if (data.colors.length) geometry.setAttribute('color', new T.Float32BufferAttribute(data.colors, 3));
        if (data.uvs && data.uvs.length) geometry.setAttribute('uv', new T.Float32BufferAttribute(data.uvs, 2));
        geometry.computeBoundingSphere();
        const material = new T.MeshStandardMaterial({
          color: data.colors.length ? 0xffffff : new T.Color().fromArray(data.color),
          vertexColors: !!data.colors.length,
          map: data.colors.length ? skinTexture : null,
          roughness: data.roughness, metalness: data.metalness,
          // Solid, thin exported fins write the same optical depth as the fish body.
          side: T.DoubleSide, envMapIntensity: .55
        });
        const mesh = new T.Mesh(geometry, material); mesh.name = data.name;
        mesh.castShadow = true; mesh.receiveShadow = true;
        if (data.part === 'caudal') {
          // Geometry remains in model space. Offset once around its real tail wrist.
          mesh.position.x = .061; tail.add(mesh);
        } else root.add(mesh);
        geometries.push(geometry); materials.push(material);
      });
      function update(fishState) {
        if (disposed) return;
        enabled = !!(fishState && fishState.enabled);
        root.visible = enabled;
        if (!fishState) return;
        state = fishState.state || (enabled ? 'swimming' : 'disabled');
        time = Number.isFinite(fishState.time) ? fishState.time : 0;
        const p = fishState.mouth;
        if (!p || ![p.x, p.y, p.z].every(Number.isFinite)) { root.visible = false; enabled = false; return; }
        physicalMouth.set(p.x, p.y, p.z);
        const d = fishState.direction;
        if (d && [d.x,d.y,d.z].every(Number.isFinite)) {
          direction.set(d.x,d.y,d.z);
          if (direction.lengthSq() < 1e-16) direction.copy(axis);
          else direction.normalize();
        }
        root.quaternion.setFromUnitVectors(axis, direction);
        // The exported landmark is measured from the ACTUAL lip mesh, not an independently
        // repositioned marker. Apply the same root transform to the real geometry and point.
        root.position.copy(physicalMouth).sub(actualMouth.copy(mouth).applyQuaternion(root.quaternion));
        const speed = Number.isFinite(fishState.speed) ? Math.max(0,fishState.speed) : .025;
        tail.rotation.y = enabled ? Math.sin(time * (7 + Math.min(speed, .3) * 25)) * (.09 + Math.min(speed, .3) * .5) : 0;
        root.updateMatrixWorld(true);
        actualMouth.copy(mouth).applyMatrix4(root.matrixWorld);
      }
      function snapshot() {
        // Recompute from the rendered root, rather than reporting a copied behavior coordinate.
        root.updateMatrixWorld(true);
        actualMouth.copy(mouth).applyMatrix4(root.matrixWorld);
        return {
          enabled, visible: root.visible, state, time,
          modelMouth: { x: actualMouth.x, y: actualMouth.y, z: actualMouth.z },
          physicalMouth: { x: physicalMouth.x, y: physicalMouth.y, z: physicalMouth.z },
          error: actualMouth.distanceTo(physicalMouth),
          modelMouthLocal: mouth.toArray(), mouthSource: { ...mouthSource },
          position: { x: root.position.x, y: root.position.y, z: root.position.z },
          direction: { x: direction.x, y: direction.y, z: direction.z },
          counts: { ...asset.counts }
        };
      }
      function dispose() {
        if (disposed) return;
        disposed = true; scene.remove(root);
        geometries.forEach(g => g.dispose()); materials.forEach(m => m.dispose());
        if (skinTexture) skinTexture.dispose();
      }
      // Initialize the hidden geometry consistently; it is never enabled implicitly.
      update({enabled:false,mouth:{x:0,y:0,z:0},direction:{x:1,y:0,z:0},time:0});
      return { update, snapshot, dispose };
    }
  };
})();
