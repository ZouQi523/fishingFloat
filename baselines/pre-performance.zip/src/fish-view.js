/* Scanned fish in the original scene. Physical mouth and pose are never offset for appearance. */
(function () {
  'use strict';
  window.FishView = {
    create({ THREE: T, scene }) {
      const asset = window.CrucianMesh;
      if (!asset?.meshes || !window.FishCollision) throw new Error('Load scanned fish and shared collision pose before FishView');
      const root = new T.Group(); root.name = 'CrucianFish'; root.visible = false; scene.add(root);
      const source = asset.mouthSource, lip = asset.meshes.find(m => m.name === source.mesh);
      if (!lip || !source.vertexIndices?.length) throw new Error('Scanned fish requires actual oral-rim vertex landmarks');
      const mouth = new T.Vector3();
      // Measure the same Float32 vertices that reach the GPU, not a separate free marker.
      source.vertexIndices.forEach(i => mouth.add(new T.Vector3(Math.fround(lip.positions[i*3]), Math.fround(lip.positions[i*3+1]), Math.fround(lip.positions[i*3+2]))));
      mouth.divideScalar(source.vertexIndices.length);
      const physicalMouth = new T.Vector3(), actualMouth = new T.Vector3(), direction = new T.Vector3(1,0,0);
      const geometries = [], materials = [], meshes = [], textures = [], animated = [];
      let enabled = false, disposed = false, time = 0, lastTime = NaN, state = 'disabled', habitat = null;
      (asset.textures || []).forEach(s => {
        const bytes = atob(s.data), rgba = new Uint8Array(bytes.length);
        for (let i=0;i<bytes.length;i++) rgba[i]=bytes.charCodeAt(i);
        const texture = new T.DataTexture(rgba,s.width,s.height,T.RGBAFormat);
        texture.colorSpace=T.SRGBColorSpace;texture.flipY=!!s.flipY;
        texture.magFilter=T.LinearFilter;texture.minFilter=T.LinearMipmapLinearFilter;
        texture.generateMipmaps=true;texture.anisotropy=4;texture.needsUpdate=true;textures.push(texture);
      });
      asset.meshes.forEach(data => {
        const geometry = new T.BufferGeometry();
        geometry.setAttribute('position',new T.Float32BufferAttribute(data.positions,3));
        geometry.setAttribute('normal',new T.Float32BufferAttribute(data.normals,3));
        if (data.uvs?.length) geometry.setAttribute('uv',new T.Float32BufferAttribute(data.uvs,2));
        if (data.colors?.length) geometry.setAttribute('color',new T.Float32BufferAttribute(data.colors,3));
        geometry.computeBoundingSphere();
        const material = new T.MeshStandardMaterial({
          color:new T.Color().fromArray(data.color||[1,1,1]),vertexColors:!!data.colors?.length,
          map:textures[data.textureIndex]||null,roughness:data.roughness??.68,metalness:data.metalness??0,
          side:T.DoubleSide,envMapIntensity:.55
        });
        const mesh=new T.Mesh(geometry,material);mesh.name=data.name;mesh.castShadow=true;mesh.receiveShadow=true;root.add(mesh);
        geometries.push(geometry);materials.push(material);meshes.push(mesh);
        animated.push({position:geometry.attributes.position,normal:geometry.attributes.normal,base:Float32Array.from(data.positions),baseNormal:Float32Array.from(data.normals)});
      });
      function deform(t) {
        const d=asset.deformation;if(!d)return;
        for(const a of animated){const p=a.position.array,n=a.normal.array;
          for(let i=0;i<p.length;i+=3){const x=a.base[i],u=Math.max(0,Math.min(1,(-x+d.startX)/d.span));
            const phase=t*d.frequency+u*d.phase,amp=d.amplitude*u*u;
            p[i+2]=a.base[i+2]+amp*Math.sin(phase);
            const derivative=u>0&&u<1?-(2*d.amplitude*u*Math.sin(phase)+amp*d.phase*Math.cos(phase))/d.span:0;
            const nx=a.baseNormal[i]-derivative*a.baseNormal[i+2],ny=a.baseNormal[i+1],nz=a.baseNormal[i+2],len=Math.hypot(nx,ny,nz)||1;
            n[i]=nx/len;n[i+1]=ny/len;n[i+2]=nz/len;
          }a.position.needsUpdate=true;a.normal.needsUpdate=true;
        }
      }
      function update(fishState) {
        if(disposed)return;enabled=!!fishState?.enabled;root.visible=enabled;if(!fishState)return;
        state=fishState.state||(enabled?'swimming':'disabled');time=Number.isFinite(fishState.time)?fishState.time:0;
        const p=fishState.mouth;if(!p||![p.x,p.y,p.z].every(Number.isFinite)){root.visible=false;enabled=false;return;}
        physicalMouth.set(p.x,p.y,p.z);const d=fishState.direction;if(d)direction.set(d.x,d.y,d.z).normalize();
        const q=fishState.poseQuaternion||window.FishCollision.orientation(direction);
        root.quaternion.set(q.x,q.y,q.z,q.w);
        root.position.copy(physicalMouth).sub(actualMouth.copy(mouth).applyQuaternion(root.quaternion));
        if(time!==lastTime){deform(time);lastTime=time;}root.updateMatrixWorld(true);
      }
      function snapshot() {
        root.updateMatrixWorld(true);actualMouth.copy(mouth).applyMatrix4(root.matrixWorld);
        const min={x:Infinity,y:Infinity,z:Infinity},max={x:-Infinity,y:-Infinity,z:-Infinity};let terrainPenetration=0;
        // Independent QA of actual deformed render vertices; not a collision-hull self-test.
        const v=new T.Vector3();for(const mesh of meshes){const p=mesh.geometry.attributes.position;
          for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i).applyMatrix4(mesh.matrixWorld);
            for(const k of ['x','y','z']){min[k]=Math.min(min[k],v[k]);max[k]=Math.max(max[k],v[k]);}
            if(habitat)terrainPenetration=Math.max(terrainPenetration,habitat.heightAt(v.x,v.z)-v.y);
          }}
        return{enabled,visible:root.visible,state,time,modelId:asset.id,modelHash:asset.modelHash,modelMouth:{x:actualMouth.x,y:actualMouth.y,z:actualMouth.z},physicalMouth:{x:physicalMouth.x,y:physicalMouth.y,z:physicalMouth.z},error:actualMouth.distanceTo(physicalMouth),modelMouthLocal:mouth.toArray(),mouthSource:{...source,vertexCount:source.vertexIndices.length},position:{x:root.position.x,y:root.position.y,z:root.position.z},direction:{x:direction.x,y:direction.y,z:direction.z},poseQuaternion:{x:root.quaternion.x,y:root.quaternion.y,z:root.quaternion.z,w:root.quaternion.w},counts:{...asset.counts},bounds:{min,max},terrainPenetration};
      }
      function setHabitat(value){habitat=value;}
      function dispose(){if(disposed)return;disposed=true;scene.remove(root);geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());}
      update({enabled:false,mouth:{x:0,y:0,z:0},direction:{x:1,y:0,z:0},time:0});
      return{update,snapshot,setHabitat,dispose};
    }
  };
})();
